class Book:
    def __init__(self, isbn, title, year, price):
        self.isbn = isbn
        self.title = title
        self.year = year
        self.price = price

    def is_for_sale(self):
        return True

class PaperBook(Book):
    def __init__(self, isbn, title, year, price, stock):
        super().__init__(isbn, title, year, price)
        self.stock = stock

class EBook(Book):
    def __init__(self, isbn, title, year, price, filetype):
        super().__init__(isbn, title, year, price)
        self.filetype = filetype

class ShowcaseBook(Book):
    def __init__(self, isbn, title, year, price):
        super().__init__(isbn, title, year, price)

    def is_for_sale(self):
        return False 