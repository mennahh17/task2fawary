from bookstore import Bookstore
from book import PaperBook, EBook, ShowcaseBook

def main():
    store = Bookstore()
    while True:
        print("\n1. Add Book\n2. Buy Book\n3. Remove Outdated Books\n4. Exit")
        choice = input("Choose an option: ")
        if choice == '1':
            book_type = input("Enter type (paper/ebook/showcase): ").strip().lower()
            isbn = input("ISBN: ")
            title = input("Title: ")
            year = int(input("Year: "))
            price = float(input("Price: "))
            if book_type == 'paper':
                stock = int(input("Stock: "))
                book = PaperBook(isbn, title, year, price, stock)
            elif book_type == 'ebook':
                filetype = input("Filetype: ")
                book = EBook(isbn, title, year, price, filetype)
            elif book_type == 'showcase':
                book = ShowcaseBook(isbn, title, year, price)
            else:
                print("Unknown type.")
                continue
            store.add_book(book)
            print("Book added.")
        elif choice == '2':
            isbn = input("ISBN to buy: ")
            quantity = int(input("Quantity: "))
            email = input("Email: ")
            address = input("Address: ")
            try:
                paid = store.buy_book(isbn, quantity, email, address)
                print(f"Purchase successful, paid: {paid}")
            except Exception as e:
                print(f"Error: {e}")
        elif choice == '3':
            years = int(input("Remove books older than how many years? "))
            removed = store.remove_outdated_books(years)
            print(f"Removed books: {[b.title for b in removed]}")
        elif choice == '4':
            print("Goodbye!")
            break
        else:
            print("Invalid choice.")

if __name__ == '__main__':
    main() 