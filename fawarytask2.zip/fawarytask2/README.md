# Quantum Bookstore

This is a simple, extensible online bookstore system implemented in Python.

## Features
- Supports PaperBook, EBook, and ShowcaseBook types
- Add books to inventory
- Remove outdated books by year
- Buy books (with inventory and delivery logic)
- Easily extensible for new book types

## Files
- `book.py`: Book classes
- `services.py`: Service stubs for shipping/email
- `bookstore.py`: Inventory and operations
- `test_bookstore.py`: test script

## Extending
To add a new book type, subclass `Book` and update logic in `Bookstore` if needed. 