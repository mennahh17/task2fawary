from book import Book, PaperBook, EBook, ShowcaseBook
from services import ShippingService, MailService
from datetime import datetime

class Bookstore:
    def __init__(self):
        self.inventory = {}

    def add_book(self, book):
        self.inventory[book.isbn] = book

    def remove_outdated_books(self, years):
        current_year = datetime.now().year
        to_remove = [isbn for isbn, book in self.inventory.items() if current_year - book.year > years]
        removed_books = [self.inventory.pop(isbn) for isbn in to_remove]
        return removed_books

    def buy_book(self, isbn, quantity, email, address):
        if isbn not in self.inventory:
            raise ValueError("Book not found")
        book = self.inventory[isbn]
        if not book.is_for_sale():
            raise ValueError("This book is not for sale")
        if isinstance(book, PaperBook):
            if book.stock < quantity:
                raise ValueError("Not enough stock available")
            book.stock -= quantity
            ShippingService.send(book, address)
            return book.price * quantity
        elif isinstance(book, EBook):
            MailService.send(book, email)
            return book.price * quantity
        else:
            raise ValueError("Cannot buy this type of book") 