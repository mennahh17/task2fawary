class ShippingService:
    @staticmethod
    def send(book, address):
        print(f"Shipping '{book.title}' to {address}")

class MailService:
    @staticmethod
    def send(book, email):
        print(f"Emailing '{book.title}' ({book.filetype}) to {email}") 